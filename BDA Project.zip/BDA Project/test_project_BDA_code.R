library(tidyverse)
library(brms)
library(bayesplot)
library(loo)
library(reliabilitydiag)
library(ggplot2)

# 1. Load and clean data
data_clean <- read.csv("https://vincentarelbundock.github.io/Rdatasets/csv/DAAG/nassCDS.csv") %>%
  drop_na(yearVeh) %>%
  mutate(
    y = if_else(dead == "dead", 1, 0),
    seatbelt = factor(seatbelt, levels = c("none", "belted")),
    airbag   = factor(airbag, levels = c("none", "airbag")),
    dvcat    = factor(dvcat, levels = c("1-9km/h", "10-24", "25-39", "40-54", "55+")),
    yearVeh  = as.factor(yearVeh)
  )

# 2. Define informative priors
priors_m1 <- c(
  prior(normal(-3.5, 1), class = "Intercept"),
  prior(normal(-0.2, 0.2), class = "b", coef = "seatbeltbelted"),
  prior(normal(-0.1, 0.3), class = "b", coef = "airbagairbag"),
  prior(normal(0.3, 1), class = "b", coef="dvcat10M24"),
  prior(normal(1.1, 0.8), class = "b", coef="dvcat25M39"),
  prior(normal(1.8, 0.7), class = "b", coef="dvcat40M54"),
  prior(normal(2.4, 0.3), class = "b", coef="dvcat55P")
)

priors_m2 <- c(
  priors_m1,
  prior(normal(0,1), class = "sd", group = "yearVeh")
)

# Model 1: Non-Hierarchical Logistic Model
m1_nonhier <- brm(
  formula = y ~ 1 + seatbelt + airbag + dvcat,
  data    = data_clean,
  family  = bernoulli(link = "logit"),
  prior   = priors_m1,
  chains  = 4,
  iter    = 3000,
  warmup  = 1000,
  control = list(adapt_delta = 0.95, max_treedepth = 12),
  cores   = 4,
  seed    = 42
)

# Model 2: Hierarchical Logistic Model (Varying Intercept by Vehicle Year)
m2_hier <- brm(
  formula = y ~ 1 + seatbelt + airbag + dvcat + (1 | yearVeh),
  data    = data_clean,
  family  = bernoulli(link = "logit"),
  prior   = priors_m2,
  chains  = 4,
  iter    = 3000,
  warmup  = 1000,
  control = list(adapt_delta = 0.95, max_treedepth = 12),
  cores   = 4,
  seed    = 42
)

# Save brmsfit to RDS file
#saveRDS(m1_nonhier, file = "notebooks/BDA Project/m1_nonhier.rds")
#saveRDS(m2_hier, file = "notebooks/BDA Project/m2_hier.rds")
# Read brmsfit from RDS file
m1_nonhier <- readRDS("notebooks/BDA Project/m1_nonhier.rds")
m2_hier <- readRDS("notebooks/BDA Project/m2_hier.rds")

# Summary checks for R-hat, ESS, and Divergences
summary(m1_nonhier)
summary(m2_hier)

# Extract MCMC diagnostic summary
np_m2 <- nuts_params(m2_hier$fit)
num_divergences <- sum(subset(np_m2, Parameter == "divergent__")$Value)
cat("Number of divergent transitions (Model 2):", num_divergences, "\n")

# Trace plot inspection for key parameters
mcmc_trace(m2_hier, pars = c("b_Intercept", "b_seatbeltbelted", "b_airbagairbag", "sd_yearVeh__Intercept"))

# ==============================================================================
# 1. POSTERIOR PREDICTIVE CHECKS (Binary-appropriate checks for both models)
# ==============================================================================

# --- Model 1: predictive probabilities for reliability diagram ---

# posterior predictive probabilities (not 0/1 outcomes)
p_epred1 <- posterior_epred(
  m1_nonhier,
  newdata = data_clean,
  ndraws  = 1000         # moderate number of draws to avoid memory issues
)

# average over draws to get Pr(y=1 | data, model) per observation
p_hat1 <- colMeans(p_epred1)

# observed outcomes for the same subset
y_obs <- data_clean$y

# PAV-adjusted reliability diagram (recommended for binary targets) [2]
rd1 <- reliabilitydiag(
  EMOS = p_hat1,
  y    = y_obs
)

autoplot(rd1) +
  labs(
    x = "Predicted probability of fatality",
    y = "Conditional event probabilities"
  ) +
  ggtitle("Calibration (PAV) – Model 1: Non-hierarchical (subset)")

# --- Model 2: predictive probabilities for reliability diagram ---

p_epred2 <- posterior_epred(
  m2_hier,
  newdata = data_clean,
  ndraws  = 1000
)

p_hat2 <- colMeans(p_epred2)

rd2 <- reliabilitydiag(
  EMOS = p_hat2,
  y    = y_obs
)

autoplot(rd2) +
  labs(
    x = "Predicted probability of fatality",
    y = "Conditional event probabilities"
  ) +
  ggtitle("Calibration (PAV) – Model 2: Hierarchical (subset)")
